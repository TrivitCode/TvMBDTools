
// TesterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Tester.h"
#include "TesterDlg.h"
#include "afxdialogex.h"
#include "TvDBClientMSSQL.h"
#include <TvUtils.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CTesterDlg dialog



CTesterDlg::CTesterDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_TESTER_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTesterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_PATHNAME, m_Pathname);
	DDX_Control(pDX, IDC_EDIT_PATH_NAME_2, m_Pathname2);
}

BEGIN_MESSAGE_MAP(CTesterDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &CTesterDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CTesterDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CTesterDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CTesterDlg::OnBnClickedButton4)
END_MESSAGE_MAP()


// CTesterDlg message handlers

BOOL CTesterDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_Pathname. SetWindowText(L"E:\\BitBucket\\TvMBDTools\\Tester\\ProFeatType.h");
	m_Pathname2.SetWindowText(L"E:\\BitBucket\\TvMBDTools\\Tester\\ProObjects.h");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTesterDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTesterDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTesterDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

#include <iostream>
#include <string>
using namespace std;

#include <stdio.h>
#define OTL_ODBC_MSSQL_2008 // Compile OTL 4/ODBC, MS SQL 2008
//#define OTL_ODBC // Compile OTL 4/ODBC. Uncomment this when used with MS SQL 7.0/ 2000
#define OTL_UNICODE // Enable Unicode OTL for ODBC

#if defined(__GNUC__)

namespace std {
	typedef unsigned short unicode_char;
	typedef basic_string<unicode_char> unicode_string;
}

#define OTL_UNICODE_CHAR_TYPE unicode_char
#define OTL_UNICODE_STRING_TYPE unicode_string

#else

#define OTL_UNICODE_CHAR_TYPE wchar_t
#define OTL_UNICODE_STRING_TYPE wstring
#endif

#if (defined(__clang__) || defined(__GNUC__)) && \
    (defined(OTL_CPP_14_ON) || defined(OTL_CPP_17_ON))
#include <experimental/string_view>
#define OTL_STD_UNICODE_STRING_VIEW_CLASS std::experimental::basic_string_view<unicode_char>
#elif defined(_MSC_VER) && (_MSC_VER>=1910) && defined(OTL_CPP_17_ON)
// VC++ 2017 or higher when /std=c++latest is used
#include <string_view>
#define OTL_STD_UNICODE_STRING_VIEW_CLASS std::basic_string_view<wchar_t>
#endif

#include "otlv4.h" // include the OTL 4.0 header file

otl_connect db; // connect object

void insert()
// insert rows into table
{
	otl_stream o(50, // buffer size
		"insert into test_tab values(:f1<int>,:f2<varchar[32]>)",
		// SQL statement, char[5] means 5 2-byte 
		// Unicode characters including a null
		// terminator
		db // connect object
	);

	OTL_UNICODE_CHAR_TYPE tmp[32];
	OTL_UNICODE_STRING_TYPE tmp2 = L"Hello";

	for (int i = 1; i <= 20; ++i) {
		o << i;
		//tmp[0] = 1111; // Unicode character (decimal code of 1111)
		//tmp[1] = 2222; // Unicode character (decimal code of 2222)
		//tmp[2] = 3333; // Unicode character (decimal code of 3333)
		//tmp[3] = 4444; // Unicode character (decimal code of 4444)
		//tmp[4] = 0; // Unicode null terminator 
		//tmp2 = tmp;
		swprintf_s(tmp, L"Hello_%d", i);
		tmp2 = tmp;
#if defined(OTL_STD_UNICODE_STRING_VIEW_CLASS)
		OTL_STD_UNICODE_STRING_VIEW_CLASS tmp2_sv(tmp2.c_str(), tmp2.length());
		o << tmp2_sv;
#else
		o << tmp2;
#endif
	}

}

void select()
{
	otl_stream i(50, // buffer size
		"select * from test_tab "
		"where f1>=:f11<int> "
		"  and f1<=:f12<int>*2",
		// SELECT statement
		db // connect object
	);
	// create select stream

	int f1;
	OTL_UNICODE_STRING_TYPE f2;

	i << 8 << 8; // assigning :f11 = 8, f12 = 8
				 // SELECT automatically executes when all input variables are
				 // assigned. First portion of output rows is fetched to the buffer

	while (!i.eof()) { // while not end-of-data
		i >> f1;
		i >> f2;
		cout << "f1=" << f1 << ", f2=";
		for (size_t j = 0; j<f2.length(); ++j)
			cout << " " << f2[j];
		cout << endl;
	}

	i << 4 << 4; // assigning :f11 = 4, :f12 = 4
				 // SELECT automatically executes when all input variables are
				 // assigned. First portion of output rows is fetched to the buffer

	while (!i.eof()) { // while not end-of-data
		i >> f1 >> f2;
		cout << "f1=" << f1 << ", f2=";
		for (int j = 0; f2[j] != 0; ++j)
			cout << " " << f2[j];
		cout << endl;
	}

}

void CTesterDlg::OnBnClickedButton1()
{
	TestProc3();

	return ;
}

int CTesterDlg::TestProc2()
{
	otl_connect::otl_initialize(); // initialize ODBC environment
	try {

		db.rlogon("trivit", "#trivit1", "sql"); // connect to ODBC

		otl_cursor::direct_exec
		(
			db,
			"drop table test_tab",
			otl_exception::disabled // disable OTL exceptions
		); // drop table
		db.commit();
		
		otl_cursor::direct_exec
		(
			db,
			"create table test_tab(f1 int, f2 varchar(32))"
		);  // create table
		//db.commit();

		insert(); // insert records into table

		//select(); // select records from table

	}

	catch (otl_exception& p) { // intercept OTL exceptions
		cerr << p.msg << endl; // print out error message
		cerr << p.stm_text << endl; // print out SQL that caused the error
		cerr << p.sqlstate << endl; // print out SQLSTATE message
		cerr << p.var_info << endl; // print out the variable that caused the error
	}

	db.logoff(); // disconnect from Oracle

	return 0;
}


int CTesterDlg::TestProc1() 
{

//#define SQL_RESULT_LEN 240
//#define SQL_RETURN_CODE_LEN 1000
//
//	//define handles and variables
//	SQLHANDLE sqlConnHandle;
//	SQLHANDLE sqlStmtHandle;
//	SQLHANDLE sqlEnvHandle;
//	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
//
//	//initializations
//	sqlConnHandle = NULL;
//	sqlStmtHandle = NULL;
//
//	//allocations
//	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
//		goto COMPLETED;
//
//	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
//		goto COMPLETED;
//
//	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
//		goto COMPLETED;
//
//	//output
//	cout << "Attempting connection to SQL Server...";
//	cout << "\n";
//
//	//connect to SQL Server  
//	//I am using a trusted connection and port 14808
//	//it does not matter if you are using default or named instance
//	//just make sure you define the server name and the port
//	//You have the option to use a username/password instead of a trusted connection
//	//but is more secure to use a trusted connection
//	switch (SQLDriverConnect(sqlConnHandle,
//		NULL,
//		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
//		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;Trusted=true;",
//		(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=TV_MBDTOOLS;UID=trivit;PWD=#trivit1;",
//		SQL_NTS,
//		retconstring,
//		1024,
//		NULL,
//		SQL_DRIVER_NOPROMPT)) {
//
//	case SQL_SUCCESS:
//		cout << "Successfully connected to SQL Server";
//		cout << "\n";
//		break;
//
//	case SQL_SUCCESS_WITH_INFO:
//		cout << "Successfully connected to SQL Server";
//		cout << "\n";
//		break;
//
//	case SQL_INVALID_HANDLE:
//		cout << "Could not connect to SQL Server";
//		cout << "\n";
//		goto COMPLETED;
//
//	case SQL_ERROR:
//		cout << "Could not connect to SQL Server";
//		cout << "\n";
//		goto COMPLETED;
//
//	default:
//		break;
//	}
//
//	//if there is a problem connecting then exit application
//	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
//		goto COMPLETED;
//
//	//output
//	cout << "\n";
//	cout << "Executing T-SQL query...";
//	cout << "\n";
//
//	//if there is a problem executing the query then exit application
//	//else display query result
//	//if (SQL_SUCCESS != SQLExecDirect(sqlStmtHandle, (SQLWCHAR*)L"SELECT @@VERSION", SQL_NTS)) {
//	SQLRETURN retCode = SQLExecDirect(sqlStmtHandle, (SQLWCHAR*)L"DROP TABLE test_tab", 19);
//	if (SQL_SUCCESS != retCode) {
//		cout << "Error querying SQL Server";
//		cout << "\n";
//		goto COMPLETED;
//	}
//	else {
//
//		//declare output variable and pointer
//		SQLCHAR sqlVersion[SQL_RESULT_LEN];
//		SQLINTEGER ptrSqlVersion;
//		SQLLEN intSqlLen;
//
//		while (SQLFetch(sqlStmtHandle) == SQL_SUCCESS) {
//
//			SQLGetData(sqlStmtHandle, 1, SQL_CHAR, sqlVersion, SQL_RESULT_LEN, &intSqlLen);
//
//			//display query result
//			//cout << "\nQuery Result:\n\n";
//			//cout << sqlVersion << endl;
//			CString msg(sqlVersion);
//			AfxMessageBox(msg);
//		}
//	}
//
//	//close connection and free resources
//COMPLETED:
//	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
//	SQLDisconnect(sqlConnHandle);
//	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
//	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
//
//	//pause the console window - exit when key is pressed
//	cout << "\nPress any key to exit...";
//	getchar();

	return 0;
}

int CTesterDlg::TestProc3()
{
	TvDBClientMSSQL db;
	if (!db.Initialize(L"localhost", 1433, L"TV_MBDTOOLS", L"trivit", L"#trivit1"))
		return -1;

	CString sql;
	for (int i = 0; i < 10; i++)
	{
		CTime time = CTime::GetCurrentTime();

		sql.Format(L"INSERT INTO Model \n(name, type, revision, iteration, createStamp)\nVALUES(\'name_%02d\',\'type3\',\'rev3\',3,\'2020-13-12 17:00:01.010\')", i);

		CStringArray msg;
		if (!db.Execute(sql, &msg))
		{
			MessageBox(db.GetLastError());
			return -2;
		}
	}

	return 0;
}

void CTesterDlg::OnBnClickedButton2()
{
	TvDBClientMSSQL db;
	if (!db.Initialize(L"localhost", 1433, L"TV_MBDTOOLS", L"trivit", L"#trivit1"))
		return;

	CString sql;


	//sql = L"SELECT id FROM Model WHERE name='name1' AND type='type1' AND revision='rev' AND iteration=2";
	sql = L"SELECT id, name, type FROM Model WHERE iteration=3";

	CStringArray msg;
	if (!db.Execute(sql, &msg))
	{
		MessageBox(db.GetLastError());
		return;
	}

	INT_PTR n = msg.GetCount();

	return;
}


void CTesterDlg::OnBnClickedButton3()
{
	CString pathname;
	m_Pathname.GetWindowText(pathname);

	if (!PathFileExists(pathname))
		return;

	CStdioFile f;
	if (!f.Open(pathname, CFile::modeRead))
		return;

	CString line, iden, name, value;
	CString text = L"";
	while (f.ReadString(line))
	{
		line.Trim();
		if (line.GetLength() == 0)
			continue;

		if (line[0] == L'/')
			continue;

		iden = line.Left(7);
		if (iden.CompareNoCase(L"#define") != 0)
			continue;

		CStringArray vals;
		TvUtils::TvStringSplitString(line, L" \t", vals);
		if (vals.GetCount() < 3)
			continue;

		name = vals[1];
		value = vals[2];

		line.Format(L"\tcase %s:\n\t\tszType=L\"%s\";\n\t\tbreak;\n", name, name);
		text += line;
	}
}


void CTesterDlg::OnBnClickedButton4()
{
	CString pathname;
	m_Pathname2.GetWindowText(pathname);

	if (!PathFileExists(pathname))
		return;

	CStdioFile f;
	if (!f.Open(pathname, CFile::modeRead))
		return;

	CString line, iden, name, value;
	CString text = L"";
	bool in_def = false;
	while (f.ReadString(line))
	{
		line.Trim();
		if (line.GetLength() == 0)
			continue;

		if (line[0] == L'/')
			continue;

		iden = line;
		if (iden.CompareNoCase(L"typedef enum pro_obj_types") == 0)
		{
			in_def = true;
			continue;
		}

		if (iden.CompareNoCase(L"} ProType;") == 0)
		{
			in_def = false;
			continue;
		}

		if (!in_def)
			continue;

		CStringArray vals;
		TvUtils::TvStringSplitString(line, L"=,", vals);
		if (vals.GetCount() < 2)
			continue;

		name = vals[0];
		value = vals[1];

		name.Trim();
		value.Trim();

		line.Format(L"\tcase %s:\n\t\tszType=L\"%s\";\n\t\tbreak;\n", name, name);
		text += line;
	}
}
