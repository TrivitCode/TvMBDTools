#pragma once
#include <TvProDllApp.h>
#include <TvSolid.h>
#include <TvGeomTol.h>
#include <TvCombState.h>
#include <TvAnnotation.h>
#include "TvMBDDatabase.h"

class TvMBDApp : public TvProDllApp
{
public:
	TvMBDApp(void);
	~TvMBDApp(void);
	bool Initialize();
	bool Run();

protected:
	TvSolid* m_pSolid;
	TvGeomTolList m_GeomTols;
	TvCombStateList m_CombStates;
	TvMBDDatabase* m_pDatabase;

	bool ReadData();
	bool WriteData();
	bool UpdateDatabase();
};

