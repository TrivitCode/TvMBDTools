#pragma once
#include "TvDBClient.h"
#include "TvDBClientMSSQL.h"
#include "TvDBClientMySQL.h"

#include <TvProApp.h>
#include <TvMdl.h>
#include <TvFeature.h>
#include <TvCombState.h>
#include <TvGeomTol.h>
#include <TvAnnotation.h>
#include <TvGeomitem.h>

using namespace TvUtils;

class TvMBDDatabase : public TvProApp
{
public:
	TvMBDDatabase();
	~TvMBDDatabase();
	bool Initialize();

	bool InsertMdl(TvMdl* pMdl);
	INT_PTR FindMdl(TvMdl* pMdl);

	bool InsertFeature(TvFeature* pFeat, INT_PTR id_mdl);
	INT_PTR FindFeature(TvFeature* pFeat, INT_PTR id_mdl);

	bool InsertCombstate(TvCombState* pComb, INT_PTR id_mdl);
	INT_PTR FindCombstate(TvCombState* pComb, INT_PTR id_mdl);

	bool InsertGtol(TvGeomTol* pGtol, INT_PTR id_mdl);
	INT_PTR FindGtol(TvGeomTol* pGtol, INT_PTR id_mdl);

	bool InsertAnnotation(TvAnnotation* pAnno, INT_PTR id_mdl, INT_PTR id_comb);
	INT_PTR FindAnnotation(TvAnnotation* pAnno, INT_PTR id_mdl, INT_PTR id_comb);

	bool InsertGeomitem(TvGeomitem* pGi, INT_PTR id_mdl, INT_PTR id_feat);
	INT_PTR FindGeomitem(TvGeomitem* pGi, INT_PTR id_mdl, INT_PTR id_feat);

protected:
	TvDBClient* m_pDatabase;

	INT_PTR ExecuteFind(LPCTSTR sql);
};

