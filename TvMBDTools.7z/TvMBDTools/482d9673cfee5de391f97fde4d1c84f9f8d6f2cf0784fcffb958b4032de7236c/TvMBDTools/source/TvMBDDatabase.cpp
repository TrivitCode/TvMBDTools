#include "stdafx.h"
#include "TvMBDDatabase.h"


TvMBDDatabase::TvMBDDatabase()
{
}


TvMBDDatabase::~TvMBDDatabase()
{
}

bool TvMBDDatabase::Initialize()
{
	// get dabase configuratoions
	CString srvType = m_pOptions->GetString(L"Database", L"Source");

	if (srvType.CompareNoCase(L"MSSQL") == 0)
		m_pDatabase = new TvDBClientMSSQL();
	else if (srvType.CompareNoCase(L"MySQL") == 0)
		m_pDatabase = new TvDBClientMySQL();
	else
	{
		LogErr(L"Database not supported: %s", srvType);
		return false;
	}

	TvApp::CopyPropertiesTo(m_pDatabase);
	if (m_pDatabase == NULL)
		return false;

	CString server = m_pOptions->GetString(L"Database", L"Server");
	if (server.IsEmpty())
		return false;

	int port = m_pOptions->GetInt(L"Database", L"Port");

	CString db_name = m_pOptions->GetString(L"Database", L"Database");
	if (db_name.IsEmpty())
		return false;

	CString user_name = m_pOptions->GetString(L"Database", L"Username");
	if (user_name.IsEmpty())
		return false;

	CString passwd = m_pOptions->GetString(L"Database", L"Password");
	if (passwd.IsEmpty())
		return false;

	if (!m_pDatabase->Initialize(server, port, db_name, user_name, passwd))
	{
		LogErr(L"initialize database connection failed: %s", m_pDatabase->GetLastError());
		return false;
	}

	return true;
}

INT_PTR TvMBDDatabase::ExecuteFind(LPCTSTR sql)
{
	CStringArray msgs;
	if (!m_pDatabase->Execute(sql, &msgs))
	{
		LogErr(L"execute sql failed: %s", sql);
		return -1;
	}

	INT_PTR num = msgs.GetCount();

	if (num == 0)
		return 0;

	if (num > 1)
	{
		LogErr(L"returns more than 1 combstate: %d", msgs.GetCount());
		return -2;
	}

	INT_PTR id = _wtoll(msgs.GetAt(0));

	return id;
}

INT_PTR TvMBDDatabase::FindMdl(TvMdl* pMdl)
{
	CString sql;
	sql.Format(L"SELECT id FROM Model WHERE name = '%s' AND type = '%s' AND revision = '%s' AND iteration = %d", 
		pMdl->GetName(), pMdl->GetTypeString(), pMdl->GetRevision(), pMdl->GetIteration());

	return ExecuteFind(sql);
}

INT_PTR TvMBDDatabase::FindFeature(TvFeature* pFeat, INT_PTR id_mdl)
{
	CString sql;
	sql.Format(L"SELECT id FROM Feature WHERE owner = %lld AND idModel = %d", id_mdl, pFeat->GetID());

	return ExecuteFind(sql);
}

INT_PTR TvMBDDatabase::FindCombstate(TvCombState* pComb, INT_PTR id_mdl)
{
	CString sql;
	sql.Format(L"SELECT id FROM Combstate WHERE owner = %lld AND idModel = %d", id_mdl, pComb->GetID());

	return ExecuteFind(sql);
}

INT_PTR TvMBDDatabase::FindGtol(TvGeomTol* pGtol, INT_PTR id_mdl)
{
	CString sql;
	sql.Format(L"SELECT id FROM Gtol WHERE owner = %lld AND idModel = %d", id_mdl, pGtol->GetID());

	return ExecuteFind(sql);
}

INT_PTR TvMBDDatabase::FindAnnotation(TvAnnotation* pAnno, INT_PTR id_mdl, INT_PTR id_comb)
{
	CString sql;
	sql.Format(L"SELECT id FROM Annotation WHERE owner = %lld AND idModel = %d AND combstate = %lld", id_mdl, pAnno->GetID(), id_comb);

	return ExecuteFind(sql);
}

INT_PTR TvMBDDatabase::FindGeomitem(TvGeomitem* pGi, INT_PTR id_mdl, INT_PTR id_feat)
{
	CString sql;
	sql.Format(L"SELECT id FROM Geomitem WHERE owner = %lld AND idModel = %d AND feature = %lld", id_mdl, pGi->GetID(), id_feat);

	return ExecuteFind(sql);
}

/////////////////////////////////////////////////////////////////////////////
//
bool TvMBDDatabase::InsertMdl(TvMdl* pMdl)
{
	// check if model exits
	INT_PTR id_mdl = FindMdl(pMdl);
	if (id_mdl < 0)
		return false;

	// get current time,format: yyyy-dd-mm HH:MM:SS.ms
	SYSTEMTIME tm;
	GetSystemTime(&tm);
	CString szTime;
	szTime.Format(L"%04d-%02d-%02d %02d:%02d:%02d.%03d", tm.wYear, tm.wDay, tm.wMonth, tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);

	CString sql;
	if (id_mdl > 0)
	{
		LogMsg(L"Model found: %lld", id_mdl);

		// update mode
		sql.Format(L"UPDATE Model SET updateStamp='%s' WHERE id=%lld", szTime, id_mdl);
	}
	else
	{
		/*
		sql = L"INSERT INTO Model \n(name, type, revision, iteration, createStamp)\nVALUES(\'name3\',\'type3\',\'rev3\',3,\'2020-31-12 17:00:01.010\')";
		*/
		sql.Format(L"INSERT INTO Model \n(name, type, revision, iteration, createStamp)\nVALUES(\'%s\',\'%s\',\'%s\',%d,\'%s\')", 
			pMdl->GetName(), pMdl->GetTypeString(), pMdl->GetRevision(), pMdl->GetIteration(), szTime);
	}

	// execute
	CStringArray msgs;
	if (!m_pDatabase->Execute(sql, &msgs))
	{
		LogErr(L"execute sql failed: %s", sql);
		return false;
	}

	return true;
}

bool TvMBDDatabase::InsertFeature(TvFeature* pFeat, INT_PTR id_mdl)
{
	// check if feature exits
	INT_PTR id_feat = FindFeature(pFeat, id_mdl);
	if (id_feat < 0)
		return false;

	// get current time,format: yyyy-dd-mm HH:MM:SS.ms
	SYSTEMTIME tm;
	GetSystemTime(&tm);
	CString szTime;
	szTime.Format(L"%04d-%02d-%02d %02d:%02d:%02d.%03d", tm.wYear, tm.wDay, tm.wMonth, tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);

	CString sql;
	if (id_feat > 0)
	{
		if (m_Debug)
			LogMsg(L"Feature in database found: %lld", id_feat);

		// update mode
		sql.Format(L"UPDATE Feature SET name='%s',type='%s',status='%s',updateStamp='%s' WHERE id=%lld", 
			pFeat->GetName(), pFeat->GetTypeString(), pFeat->GetStatusString(), szTime, id_feat);
	}
	else
	{
		/*
		sql = L"INSERT INTO Model \n(name, type, revision, iteration, createStamp)\nVALUES(\'name3\',\'type3\',\'rev3\',3,\'2020-31-12 17:00:01.010\')";
		*/
		sql.Format(L"INSERT INTO Feature \n(owner, idModel, name, type, status, createStamp)\nVALUES(%lld,%d,\'%s\',\'%s\',\'%s\',\'%s\')",
			id_mdl, pFeat->GetID(), pFeat->GetName(), pFeat->GetTypeString(), pFeat->GetStatusString(), szTime);
	}

	// execute
	CStringArray msgs;
	if (!m_pDatabase->Execute(sql, &msgs))
	{
		LogErr(L"execute sql failed: %s", sql);
		return false;
	}

	return true;
}

bool TvMBDDatabase::InsertCombstate(TvCombState* pComb, INT_PTR id_mdl)
{
	// check if feature exits
	INT_PTR id_comb = FindCombstate(pComb, id_mdl);
	if (id_comb < 0)
		return false;

	// get current time,format: yyyy-dd-mm HH:MM:SS.ms
	SYSTEMTIME tm;
	GetSystemTime(&tm);
	CString szTime;
	szTime.Format(L"%04d-%02d-%02d %02d:%02d:%02d.%03d", tm.wYear, tm.wDay, tm.wMonth, tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);

	CString sql;
	if (id_comb > 0)
	{
		LogMsg(L"Combstate found: %lld", id_comb);

		// update mode
		sql.Format(L"UPDATE Combstate SET name='%s',updateStamp='%s' WHERE id=%lld",
			pComb->GetName(), szTime, id_comb);
	}
	else
	{
		// create mode
		sql.Format(L"INSERT INTO Combstate \n(owner, idModel, name, createStamp)\nVALUES(%lld,%d,\'%s\',\'%s\')",
			id_mdl, pComb->GetID(), pComb->GetName(), szTime);
	}

	// execute
	CStringArray msgs;
	if (!m_pDatabase->Execute(sql, &msgs))
	{
		LogErr(L"execute sql failed: %s", sql);
		return false;
	}

	return true;
}

bool TvMBDDatabase::InsertGtol(TvGeomTol* pGtol, INT_PTR id_mdl)
{
	// check if feature exits
	INT_PTR id_gtol = FindGtol(pGtol, id_mdl);
	if (id_gtol < 0)
		return false;

	// get current time,format: yyyy-dd-mm HH:MM:SS.ms
	SYSTEMTIME tm;
	GetSystemTime(&tm);
	CString szTime;
	szTime.Format(L"%04d-%02d-%02d %02d:%02d:%02d.%03d", tm.wYear, tm.wDay, tm.wMonth, tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);

	TvGtolComposite* pComp = pGtol->GetComposite();

	CString sql;
	if (id_gtol > 0)
	{
		LogMsg(L"Gtol found: %lld", id_gtol);

		// update mode
		sql.Format(L"UPDATE Gtol SET name='%s',type='%s',value='%s',textTop='%s',textBottom='%s',textLeft='%s',textRight='%s',compositeValue='%s',\
compositePrimary='%s',compositeSecondary='%s',compositeTertiary='%s',attachType='%s',attachId=%d,updateStamp='%s' WHERE id=%lld",
			pGtol->GetName(), pGtol->GetTypeString(), pGtol->GetValue(), pGtol->GetTextTop(), pGtol->GetTextBottom(),
			pGtol->GetTextLeft(), pGtol->GetTextRight(), TvStringArrayToLine(&pComp->Values), TvStringArrayToLine(&pComp->Primary),
			TvStringArrayToLine(&pComp->Secondary), TvStringArrayToLine(&pComp->Tertiary), pGtol->GetAttachTypeString(), pGtol->GetAttachID(), szTime, id_gtol);
	}
	else
	{
		/*
		sql = L"INSERT INTO Model \n(name, type, revision, iteration, createStamp)\nVALUES(\'name3\',\'type3\',\'rev3\',3,\'2020-31-12 17:00:01.010\')";
		*/

		sql.Format(L"INSERT INTO Gtol \n(owner,idModel,name,type,value,textTop,textBottom,textLeft,textRight,compositeValue,compositePrimary,compositeSecondary,\
compositeTertiary,attachType,attachId,createStamp)\nVALUES(%lld,%d,\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',%d,\'%s\')",
			id_mdl, pGtol->GetID(), pGtol->GetName(), pGtol->GetTypeString(), pGtol->GetValue(), pGtol->GetTextTop(), pGtol->GetTextBottom(),
			pGtol->GetTextLeft(), pGtol->GetTextRight(), TvStringArrayToLine(&pComp->Values), TvStringArrayToLine(&pComp->Primary), 
			TvStringArrayToLine(&pComp->Secondary), TvStringArrayToLine(&pComp->Tertiary), pGtol->GetAttachTypeString(), pGtol->GetAttachID(), szTime);
	}

	// execute
	CStringArray msgs;
	if (!m_pDatabase->Execute(sql, &msgs))
	{
		LogErr(L"execute sql failed: %s", sql);
		return false;
	}

	return true;
}

bool TvMBDDatabase::InsertAnnotation(TvAnnotation* pAnno, INT_PTR id_mdl, INT_PTR id_comb)
{
	// check if feature exits
	INT_PTR id_anno = FindAnnotation(pAnno, id_mdl, id_comb);
	if (id_anno < 0)
		return false;

	// get current time,format: yyyy-dd-mm HH:MM:SS.ms
	SYSTEMTIME tm;
	GetSystemTime(&tm);
	CString szTime;
	szTime.Format(L"%04d-%02d-%02d %02d:%02d:%02d.%03d", tm.wYear, tm.wDay, tm.wMonth, tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);

	CString sql;
	if (id_anno > 0)
	{
		LogMsg(L"Annotation found: %lld", id_anno);

		// update mode
		sql.Format(L"UPDATE Annotation SET name='%s',type='%s',combstate=%lld,status=%d,updateStamp='%s' WHERE id=%lld",
			pAnno->GetName(), pAnno->GetTypeString(), id_comb, pAnno->GetStatus(), szTime, id_anno);
	}
	else
	{
		// create mode
		sql.Format(L"INSERT INTO Annotation \n(owner, idModel, name, type, combstate, status, createStamp)\nVALUES(%lld,%d,\'%s\',\'%s\',%lld,%d,\'%s\')",
			id_mdl, pAnno->GetID(), pAnno->GetName(), pAnno->GetTypeString(), id_comb, pAnno->GetStatus(), szTime);
	}

	// execute
	CStringArray msgs;
	if (!m_pDatabase->Execute(sql, &msgs))
	{
		LogErr(L"execute sql failed: %s", sql);
		return false;
	}

	return true;
}

bool TvMBDDatabase::InsertGeomitem(TvGeomitem* pGi, INT_PTR id_mdl, INT_PTR id_feat)
{
	// check if geomitem exits
	INT_PTR id_gitem = FindGeomitem(pGi, id_mdl, id_feat);
	if (id_gitem < 0)
		return false;

	// get current time,format: yyyy-dd-mm HH:MM:SS.ms
	SYSTEMTIME tm;
	GetSystemTime(&tm);
	CString szTime;
	szTime.Format(L"%04d-%02d-%02d %02d:%02d:%02d.%03d", tm.wYear, tm.wDay, tm.wMonth, tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);

	CString sql;
	if (id_gitem > 0)
	{
		LogMsg(L"Geomitem found: %lld", id_gitem);

		// update mode
		sql.Format(L"UPDATE Geomitem SET name='%s',type='%s',feature=%lld,updateStamp='%s' WHERE id=%lld",
			pGi->GetName(), pGi->GetTypeString(), id_feat, szTime, id_gitem);
	}
	else
	{
		// create mode
		sql.Format(L"INSERT INTO Geomitem \n(owner, idModel, name, type, feature, createStamp)\nVALUES(%lld,%d,\'%s\',\'%s\',%lld,\'%s\')",
			id_mdl, pGi->GetID(), pGi->GetName(), pGi->GetTypeString(), id_feat, szTime);
	}

	// execute
	CStringArray msgs;
	if (!m_pDatabase->Execute(sql, &msgs))
	{
		LogErr(L"execute sql failed: %s", sql);
		return false;
	}

	return true;
}