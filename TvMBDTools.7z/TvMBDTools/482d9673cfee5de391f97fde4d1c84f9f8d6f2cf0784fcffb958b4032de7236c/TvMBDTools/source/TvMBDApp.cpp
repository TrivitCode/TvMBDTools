#include "stdafx.h"
#include "TvMBDApp.h"
#include <ProCombstate.h>
#include "TvDBClientMSSQL.h"
#include "TvDBClientMySQL.h"

ProError TvGtolVisitAction(ProGtol* gtol, ProError filter_status, ProAppData p_data)
{
	ProArrayObjectAdd((ProArray*)p_data, PRO_VALUE_UNUSED, 1, gtol);

	return PRO_TK_NO_ERROR;
}

TvMBDApp::TvMBDApp(void)
{
	m_ClassName = L"TvMBDApp";
	m_pSolid = NULL;
	m_pDatabase = NULL;
}


TvMBDApp::~TvMBDApp(void)
{
	if (m_pSolid)
	{
		delete m_pSolid;
		m_pSolid = NULL;
	}

	if (m_pDatabase)
	{
		delete m_pDatabase;
		m_pDatabase = NULL;
	}

	if (!m_GeomTols.empty())
	{
		for (size_t i = 0; i < m_GeomTols.size(); i++)
		{
			delete m_GeomTols.at(i);
			m_GeomTols.at(i) = NULL;
		}
		m_GeomTols.clear();
	}

	if (!m_CombStates.empty())
	{
		for (size_t i = 0; i < m_CombStates.size(); i++)
		{
			delete m_CombStates.at(i);
			m_CombStates.at(i) = NULL;
		}
		m_CombStates.clear();
	}
}

bool TvMBDApp::Initialize()
{
	if (!TvProDllApp::Initialize())
		return false;

	if (m_pSolid)
		delete m_pSolid;

	m_pSolid = new TvSolid;
	TvProApp::CopyPropertiesTo(m_pSolid);
	if (m_pSolid->InitializeCurrent(true, false, true) != PRO_TK_NO_ERROR)
	{
		LogErr(L"initialize current model failed");
		return false;
	}

	m_pDatabase = new TvMBDDatabase();
	TvProApp::CopyPropertiesTo(m_pDatabase);
	if (!m_pDatabase->Initialize())
	{
		LogErr(L"initialize Database connection failed");
		return false;
	}

	return true;
}

bool TvMBDApp::Run()
{
	// list all notes in solid
	if (m_pSolid == NULL)
		return false;

	if (!ReadData())
		return false;

	//if (!WriteData())
	//	return false;

	if (!UpdateDatabase())
		return false;

	return true;
}

bool TvMBDApp::ReadData()
{
	LogMsg(L"reading data from current model ...");

	/////////////////////////////////////////////////////////////////
	// get all Geometric Tolerances
	ProGtol* gtols = NULL;
	ProError err = ProArrayAlloc(0, sizeof(ProGtol), 1, (ProArray*)&gtols);
	if (err) return false;

	err = ProMdlGtolVisit(m_pSolid->GetMdl(), TvGtolVisitAction, NULL, &gtols);
	if (err) return false;

	int n_gtols = 0;
	err = ProArraySizeGet(gtols, &n_gtols);
	if (err) return false;

	for (int i = 0; i < n_gtols; i++)
	{
		TvGeomTol* pGeomTol = new TvGeomTol(gtols[i]);
		TvProApp::CopyPropertiesTo(pGeomTol);
		if (pGeomTol->Initialize() != PRO_TK_NO_ERROR)
		{
			LogErr(L"initialize TvGeomTol failed: ID_%d", gtols[i].id);
			continue;
		}

		m_GeomTols.push_back(pGeomTol);
	}

	ProArrayFree((ProArray*)&gtols);
	gtols = NULL;

	/////////////////////////////////////////////////////////////////
	// get all combined states
	ProCombstate* p_combstates = NULL;
	err = ProMdlCombstatesGet((ProSolid)m_pSolid->GetMdl(), &p_combstates);
	if (err)
	{
		LogProErr("ProMdlCombstatesGet", err);
		return false;
	}

	int n_combstates = 0;
	err = ProArraySizeGet(p_combstates, &n_combstates);
	if (err) return false;

	if (m_Debug)
		LogMsg(L"%d combined states found", n_combstates);

	for (int i = 0; i < n_combstates; i++)
	{
		TvCombState* pCs = new TvCombState(p_combstates[i]);
		TvProApp::CopyPropertiesTo(pCs);
		if (pCs->Initialize() != PRO_TK_NO_ERROR)
		{
			LogErr(L"initialize TvCombState failed: ID_%d", p_combstates[i].id);
			delete pCs;
			pCs = NULL;
			continue;
		}

		m_CombStates.push_back(pCs);
	}

	err = ProArrayFree((ProArray*)&p_combstates);
	if (err) return false;

	LogMsg(L"reading data from current model ... succeed");
	return true;
}

bool TvMBDApp::WriteData()
{
	LogMsg(L"writting data to csv file ...");

	/////////////////////////////////////////////////////////////////
	// export gtol list to text file
	CString text = L"ID;Name;Value;TopText;BottomText;LeftText;RightText;CompositeValues;CompositePrimary;CompositeSecondary;CompositeTertiary;AttachType;AttachID\r\n";
	for (size_t i = 0; i < m_GeomTols.size(); i++)
	{
		text += m_GeomTols[i]->ToString();
		text += L"\r\n";
	}

	// write it to file
	CFile f;
	if (f.Open(L"GeomTols.csv", CFile::modeCreate | CFile::modeWrite))
	{
		f.Write(text, sizeof(wchar_t)*text.GetLength());
		f.Close();
	}

	// export dimension list to text file
	TvDimensionList* pDims = m_pSolid->GetDimensions();
	if (pDims)
	{
		/*m_Modelitem.id, m_Name, m_Symbol, m_Type, m_Value, m_TolUpper, m_TolLower);*/
		text = L"ID;Name;Type;Value;TolUpper;TolLower;Text\r\n";
		for (size_t i = 0; i < pDims->size(); i++)
		{
			text += pDims->at(i)->ToString();
			text += L"\r\n";
		}

		// write it to file
		CFile f;
		if (f.Open(L"Dimensions.csv", CFile::modeCreate | CFile::modeWrite))
		{
			f.Write(text, sizeof(wchar_t)*text.GetLength());
			f.Close();
		}
	}

	// export feature list to text file
	TvFeatureList* pFeats = m_pSolid->GetFeatures();
	if (pFeats)
	{
		/*line.Format(L"\"%d\";\"%s\";\"%s\";\"%d\"", m_Modelitem.id, m_Name, m_TypeName, m_Status);*/
		text = L"ID;Name;Type;Status\r\n";
		for (size_t i = 0; i < pFeats->size(); i++)
		{
			text += pFeats->at(i)->ToString();
			text += L"\r\n";
		}

		// write it to file
		CFile f;
		if (f.Open(L"Features.csv", CFile::modeCreate | CFile::modeWrite))
		{
			f.Write(text, sizeof(wchar_t)*text.GetLength());
			f.Close();
		}
	}

	// export geom items list to text file
	if (pFeats)
	{
		/*line.Format(L"\"%d\";\"%s\";\"%d\";\"%d\"", m_Modelitem.id, m_Name, m_pGeomitemdata->obj_type, m_Owner.id);*/
		text = L"ID;Name;Type;Owner\r\n";

		for (size_t i = 0; i < pFeats->size(); i++)
		{
			TvGeomitemList* pGeis = pFeats->at(i)->GetGeomitems();
			if (pGeis)
			{
				for (size_t j = 0; j < pGeis->size(); j++)
				{
					text += pGeis->at(j)->ToString();
					text += L"\r\n";
				}

				// insert into table: GeomItems

				//MBDGeomItems gis;
				//if (gis.Open())
				//{
				//	for (size_t j = 0; j < pGeis->size(); j++)
				//	{
				//		gis.AddNew();
				//		gis.m_ID = pGeis->at(j)->GetID();
				//		gis.m_Name = pGeis->at(j)->GetName();
				//		gis.m_Owner = pGeis->at(j)->GetOwner()->id;
				//		gis.m_Type = pGeis->at(j)->GetType();
				//		if (!gis.Update())
				//		{
				//			LogErr(L"Add new item to database failed");
				//		}
				//	}
				//	gis.Close();
				//}
			}
		}

		// write it to file
		CFile f;
		if (f.Open(L"GeomItems.csv", CFile::modeCreate | CFile::modeWrite))
		{
			f.Write(text, sizeof(wchar_t)*text.GetLength());
			f.Close();
		}
	}

	// export combined states list to text file
	/*line.Format(L"\"%d\";\"%s\";\"%d\"", m_Modelitem.id, m_Name, m_Type);*/
	text = L"ID;Name;Type\r\n";
	for (size_t i = 0; i < m_CombStates.size(); i++)
	{
		text += m_CombStates.at(i)->ToString();
		text += L"\r\n";
	}

	// write it to file
	if (f.Open(L"CombStates.csv", CFile::modeCreate | CFile::modeWrite))
	{
		f.Write(text, sizeof(wchar_t)*text.GetLength());
		f.Close();
	}


	// export annotations in combined states list to text file
	/*line.Format(L"\"%d\";\"%s\";\"%d\";\"%d\";\"%d\"", m_Modelitem.id, m_Name, m_Modelitem.type, m_Status, m_CombStateID);*/
	text = L"ID;Name;Type;Status;CombStateID\r\n";
	for (size_t i = 0; i < m_CombStates.size(); i++)
	{
		TvAnnotationList* pAnnos = m_CombStates[i]->GetAnnotations();
		for (size_t i = 0; i < pAnnos->size(); i++)
		{
			text += pAnnos->at(i)->ToString();
			text += L"\r\n";
		}
	}

	// write it to file
	if (f.Open(L"Annotations.csv", CFile::modeCreate | CFile::modeWrite))
	{
		f.Write(text, sizeof(wchar_t)*text.GetLength());
		f.Close();
	}

	LogMsg(L"writting data to csv file ... succeed");

	return true;
}

bool TvMBDApp::UpdateDatabase()
{
	LogMsg(L"writting data to database ...");

	// add model to database
	if (!m_pDatabase->InsertMdl(m_pSolid))
	{
		LogErr(L"add/update model failed");
		return false;
	}

	// verify
	INT_PTR id_mdl = m_pDatabase->FindMdl(m_pSolid);
	if (id_mdl <= 0)
	{
		LogErr(L"Can't find model in database");
		return false;
	}

	// add features and geom_items to database
	TvFeatureList* pFeats = m_pSolid->GetFeatures();
	if (pFeats)
	{
		for (size_t i = 0; i < pFeats->size(); i++)
		{
			if (!m_pDatabase->InsertFeature(pFeats->at(i), id_mdl))
			{
				LogErr(L"add/update feature failed: %s, ID_%d", pFeats->at(i)->GetName(), pFeats->at(i)->GetID());
				return false;
			}

			INT_PTR id_feat = m_pDatabase->FindFeature(pFeats->at(i), id_mdl);
			if (id_feat <= 0)
			{
				LogErr(L"Can't find Feature in database");
				continue;
			}

			TvGeomitemList* pGeis = pFeats->at(i)->GetGeomitems();
			if (pGeis)
			{
				for (size_t j = 0; j < pGeis->size(); j++)
				{
					m_pDatabase->InsertGeomitem(pGeis->at(j), id_mdl, id_feat);
				}
			}
		}
	}

	// add combined states and annotations to database
	for (size_t i = 0; i < m_CombStates.size(); i++)
	{
		if (!m_pDatabase->InsertCombstate(m_CombStates.at(i), id_mdl))
		{
			LogErr(L"add/update combstate failed: %s, ID_%d", m_CombStates.at(i)->GetName(), m_CombStates.at(i)->GetID());
			return false;
		}
		// get id of Combstate in database
		INT_PTR id_comb = m_pDatabase->FindCombstate(m_CombStates[i], id_mdl);
		if (id_comb <= 0)
		{
			LogErr(L"Can't find CombState in database");
			continue;
		}

		TvAnnotationList* pAnnos = m_CombStates[i]->GetAnnotations();
		for (size_t i = 0; i < pAnnos->size(); i++)
		{
			if (!m_pDatabase->InsertAnnotation(pAnnos->at(i), id_mdl, id_comb))
			{
				LogErr(L"add/update annotation failed: %s, ID_%d, CombState ID_%d", pAnnos->at(i)->GetName(), pAnnos->at(i)->GetID(), m_CombStates[i]->GetID());
				return false;
			}
		}
	}

	// export gtol to database
	for (size_t i = 0; i < m_GeomTols.size(); i++)
	{
		if (!m_pDatabase->InsertGtol(m_GeomTols[i], id_mdl))
		{
			LogErr(L"add/update gtol failed: %s, ID_%d", m_GeomTols[i]->GetName(), m_GeomTols[i]->GetID());
			return false;
		}
	}

	LogMsg(L"writting data to database ... succeed");

	return true;
}