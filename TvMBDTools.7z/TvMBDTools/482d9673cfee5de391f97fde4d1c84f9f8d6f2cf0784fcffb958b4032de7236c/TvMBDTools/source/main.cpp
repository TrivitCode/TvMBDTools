#include "stdafx.h"

#include <ProToolkit.h>
#include <ProMessage.h>
#include <ProUICmd.h>
#include <ProUIDialog.h>
#include <TvProTkUtils.h>

#include "TvMBDApp.h"

static ProFileName MENU_FILE = L"tvmbdtools_menu.txt";
static ProFileName MSG_FILE = L"tvmbdtools_msg.txt";
static const char APP_VERSION[] = "0.1";
static const wchar_t APP_NAME[] = L"TvMBDTools";

//#ifdef _DEBUG
//CMemoryState g_oldMemState, g_newMemState, g_diffMemState;
//#endif

//TvMBDApp* g_pApp = NULL;

ProError TvMBDAppRunProc();

/////////////////////////////////////////////////////////////////////////
// Pro/TOOLKIT initialization
//
extern "C" int user_initialize(int argc,			/** Number of arguments		**/
							   char *argv[],		/** Pro/E arguments			**/
							   char *proe_vsn,		/** Pro/E version			**/
							   char *build,			/** Pro/E build				**/
							   wchar_t err_buff[])	/** Error buffer			**/
{
	ProError err = PRO_TK_NO_ERROR;
	
	// add a command: main command
	uiCmdCmdId cmd_main_run;
	err = ProCmdActionAdd("TvMBDAppRunProc", (uiCmdCmdActFn)TvMBDAppRunProc, uiProe2ndImmediate, NULL,
						  PRO_B_TRUE, PRO_B_TRUE, &cmd_main_run);
	if( err != PRO_TK_NO_ERROR )
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_PROTK_ERR", "ProCmdActionAdd", TvUtils::TvProErrors[-err]);
		return err;
	}

	// designate command
	err = ProCmdDesignate(cmd_main_run, "TV_MENU_MBD_APP_RUN", "TV_MENU_MBD_APP_RUN_TOOLTIP", "TV_MENU_MBD_APP_RUN_DESC", MENU_FILE);
	if (err)
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_PROTK_ERR", "ProCmdDesignate", TvUtils::TvProErrors[-err]);
		return err;
	}

	err = ProCmdIconSet(cmd_main_run, "TvMBDAppRun.png");
	if (err)
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_PROTK_ERR", "ProCmdIconSet", TvUtils::TvProErrors[-err]);
		return err;
	}

	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	ProMessageDisplay(MSG_FILE, "TV_APP_REG_SUCCESSED", APP_VERSION);

	return 0;
}

extern "C" void user_terminate()
{
	ProMessageDisplay(MSG_FILE, "TV_APP_EXIT");

	//if (g_pApp)
	//{
	//	delete g_pApp;
	//	g_pApp=NULL;
	//}

//#ifdef _DEBUG  
//	g_newMemState.Checkpoint();  
//	if (g_diffMemState.Difference(g_oldMemState, g_newMemState))
//	{
//		TRACE("Memory leak detected!\n");
//		ProMessageDisplay(MSG_FILE, "TV_APP_MSGW", L"Memory leak detected!");
//	}
//	else
//	{
//		TRACE("No Memory leak detected!\n");
//		ProMessageDisplay(MSG_FILE, "TV_APP_MSGW", L"No Memory leak detected!");
//	}
//#endif 
}

ProError TvMBDAppRunProc()
{
	ProError err = PRO_TK_NO_ERROR;

	TvMBDApp *g_pApp = NULL;

	g_pApp = new TvMBDApp();
	g_pApp->SetAppName(APP_NAME);
	g_pApp->SetAppVersion(CA2W(APP_VERSION));
	g_pApp->SetMsgFile(MSG_FILE);

	if (!g_pApp->Initialize())
	{
		ProMessageDisplay(MSG_FILE, "TV_APP_INIT_FAILED");
		return PRO_TK_APP_INIT_FAIL;
	}

	BOOL ret = g_pApp->Run();

	if (ret == 0)
		err = PRO_TK_NO_ERROR;
	else
		err = PRO_TK_GENERAL_ERROR;

	delete g_pApp;
	g_pApp = NULL;

	return err;
}


