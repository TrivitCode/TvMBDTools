USE [TV_MBDTOOLS]
GO

/****** Object:  Table [dbo].[Model]    Script Date: 04.11.2020 16:52:45 ******/
DROP TABLE [dbo].[Model]
GO

/****** Object:  Table [dbo].[Model]    Script Date: 04.11.2020 16:52:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Model](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](32) NOT NULL,
	[type] [nvarchar](32) NOT NULL,
	[revision] [nvarchar](32) NOT NULL,
	[iteration] [int] NOT NULL,
	[createStamp] [datetime] NULL,
	[updateStamp] [datetime] NULL,
 CONSTRAINT [PK_Model] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


