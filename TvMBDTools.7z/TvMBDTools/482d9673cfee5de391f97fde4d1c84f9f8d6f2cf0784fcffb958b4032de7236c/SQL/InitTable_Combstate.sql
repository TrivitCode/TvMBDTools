USE [TV_MBDTOOLS]
GO

/****** Object:  Table [dbo].[Combstate]    Script Date: 06.11.2020 16:11:01 ******/
DROP TABLE [dbo].[Combstate]
GO

/****** Object:  Table [dbo].[Combstate]    Script Date: 06.11.2020 16:11:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Combstate](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[owner] [bigint] NOT NULL,
	[idModel] [int] NOT NULL,
	[name] [nvarchar](32) NOT NULL,
	[createStamp] [datetime] NULL,
	[updateStamp] [datetime] NULL,
 CONSTRAINT [PK_Combstate] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


