USE [TV_MBDTOOLS]
GO

/****** Object:  Table [dbo].[Gtol]    Script Date: 04.11.2020 18:12:52 ******/
DROP TABLE [dbo].[Gtol]
GO

/****** Object:  Table [dbo].[Gtol]    Script Date: 04.11.2020 18:12:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Gtol](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[owner] [bigint] NOT NULL,
	[idModel] [int] NOT NULL,
	[name] [nvarchar](32) NOT NULL,
	[type] [nvarchar](32) NOT NULL,
	[value] [nvarchar](260) NOT NULL,
	[textTop] [nvarchar](260) NULL,
	[textBottom] [nvarchar](260) NULL,
	[textLeft] [nvarchar](260) NULL,
	[textRight] [nvarchar](260) NULL,
	[compositeValue] [nvarchar](1024) NULL,
	[compositePrimary] [nvarchar](1024) NULL,
	[compositeSecondary] [nvarchar](1024) NULL,
	[compositeTertiary] [nvarchar](1024) NULL,
	[attachType] [nvarchar](32) NOT NULL,
	[attachId] [bigint] NOT NULL,
 CONSTRAINT [PK_Gtol] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


