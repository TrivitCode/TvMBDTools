USE [TV_MBDTOOLS]
GO

/****** Object:  Table [dbo].[Geomitem]    Script Date: 04.11.2020 17:07:17 ******/
DROP TABLE [dbo].[Geomitem]
GO

/****** Object:  Table [dbo].[Geomitem]    Script Date: 04.11.2020 17:07:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Geomitem](
	[id] [bigint] IDENTITY(1,1) NOT NULL,
	[owner] [bigint] NOT NULL,
	[idModel] [int] NOT NULL,
	[feature] [bigint] NOT NULL,
	[type] [nvarchar](32) NOT NULL,
	[name] [nvarchar](32) NULL,
	[createStamp] [datetime] NULL,
	[updateStamp] [datetime] NULL,
 CONSTRAINT [PK_Geomitem] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


